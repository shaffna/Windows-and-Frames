package WindowsandFrames.WindowsandFrames;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class frames {
	static WebDriver driver;

	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();
		driver.get("http://the-internet.herokuapp.com/nested_frames");
		driver.switchTo().frame("frame-top");

		int topFrames = driver.findElements(By.cssSelector("frame")).size();
		if (topFrames == 3) {
			System.out.println("Verified: Top frame contains three frames.");
		} else {
			System.out.println("Error: Top frame does not contain three frames.");
		}
		driver.switchTo().frame("frame-left");
		WebElement leftText = driver.findElement(By.xpath("//body[contains(text(),'LEFT')]"));
		if (leftText != null) {
			System.out.println("Verified: Left frame contains text - " + leftText.getText());
		} else {
			System.out.println("Error: Left frame does not contain expected text.");
		}
		driver.switchTo().parentFrame();
		driver.switchTo().frame("frame-middle");
		WebElement middleText = driver.findElement(By.xpath("//div[contains(text(),'MIDDLE')]"));
		if (middleText != null) {
			System.out.println("Verified: Middle frame contains text - " + middleText.getText());
		} else {
			System.out.println("Error: Middle frame does not contain expected text.");
		}
		driver.switchTo().parentFrame();

		driver.switchTo().frame("frame-right");
		WebElement rightText = driver.findElement(By.xpath("//body[contains(text(),'RIGHT')]"));
		if (rightText != null) {
			System.out.println("Verified: Right frame contains text - " + rightText.getText());
		} else {
			System.out.println("Error: Right frame does not contain expected text.");
		}
		driver.switchTo().parentFrame();
		driver.switchTo().defaultContent();
		driver.switchTo().frame("frame-bottom");
		WebElement bottomText = driver.findElement(By.xpath("//body[contains(text(),'BOTTOM')]"));
		if (bottomText != null) {
			System.out.println("Verified: Bottom frame contains text - " + bottomText.getText());
		} else {
			System.out.println("Error: Bottom frame does not contain expected text.");
		}

		driver.switchTo().defaultContent();
		String pageTitle = driver.getTitle();
		if (pageTitle.equals("Frames")) {
			System.out.println("Verified: Page title is - " + pageTitle);
		} else {
			System.out.println("Error: Page title does not match expected value. Actual title: " + pageTitle);
		}
		driver.quit();

	}
}
