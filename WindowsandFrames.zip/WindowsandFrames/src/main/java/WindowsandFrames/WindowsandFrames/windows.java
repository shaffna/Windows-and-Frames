package WindowsandFrames.WindowsandFrames;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class windows {
	static WebDriver driver;

	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();
		driver.get("https://the-internet.herokuapp.com/windows");
		WebElement ClickHere = driver.findElement(By.linkText("Click Here"));
		ClickHere.click();
		String parentwindow = driver.getWindowHandle();
		for (String WindowHandle : driver.getWindowHandles()) {
			if (!WindowHandle.equals(parentwindow)) {
				driver.switchTo().window(WindowHandle);
				break;
			}
		}
		waitForFixTime(5000);
		WebElement newWindowText = new WebDriverWait(driver, Duration.ofSeconds(10))
				.until(ExpectedConditions.visibilityOfElementLocated(By.tagName("h3")));
		String text = newWindowText.getText();
		if (text.equals("New Window")) {
			System.out.println("Verified: Text on the new window is - " + text);
		} else {
			System.out.println("Error: Text on the new window does not match. Actual text: " + text);
		}
		waitForFixTime(5000);
		driver.close();
		driver.switchTo().window(parentwindow);

		if (driver.getWindowHandle().equals(parentwindow)) {
			System.out.println("Verified: Parent window is active.");
		} else {
			System.out.println("Error: Parent windowis not active.");
		}
		waitForFixTime(3000);
		driver.quit();
	}

	public static void waitForFixTime(int time) {
		try {
			Thread.sleep(time);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
